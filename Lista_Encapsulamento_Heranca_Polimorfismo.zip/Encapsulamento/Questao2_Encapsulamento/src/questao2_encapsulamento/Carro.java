/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao2_encapsulamento;

/**
 *
 * @author Usuário
 */
public class Carro {
    private String marca;
    private String cor;
    private int ano;
    public Carro(String marca, String cor, int ano) {
        this.marca = marca;
        this.cor = cor;
        this.ano = ano;
    }
}
