/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao5_heranca;

/**
 *
 * @author Usuário
 */
public class RadioRelogio implements Radio{

    @Override
    public void setEmissora() {
       
    }

    @Override
    public String getEmissora() {
        
    }

    @Override
    public int getTipoEmissora() {
        
    }

    @Override
    public void setVolumeRadio(int volume) {
        
    }

    @Override
    public int getVolume() {
        
    }
    
}
 
