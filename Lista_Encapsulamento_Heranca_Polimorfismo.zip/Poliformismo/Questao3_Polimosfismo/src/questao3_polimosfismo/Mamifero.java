/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questao3_polimosfismo;

/**
 *
 * @author Usuário
 */
public class Mamifero extends Animal{
    @Override
    public  void locomover(){
        //Código
    }
    @Override
    public void alimentar(){
        //Código
    }
        
    
}
